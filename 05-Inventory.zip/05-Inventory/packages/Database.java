package packages;
import java.sql.*;

public class Database{
	private Connection conn;
	private Statement stm;

	public Database(String database_name, String username, String password){
		try{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+database_name+"?useSSL=false", username, password);
			stm = conn.createStatement();
		} catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
	}
	public void describeTable(String table_name){
		try{
			ResultSet rs = stm.executeQuery("select * from "+table_name);
			ResultSetMetaData rsmd = rs.getMetaData();
			System.out.println("No. of columns : " + rsmd.getColumnCount());
			for(int i = 0; i < rsmd.getColumnCount(); i++){
				System.out.println("Column name of column " + (i+1) + ": " + rsmd.getColumnName(i+1));
				System.out.println("Column type of column " + (i+1) + ": " + rsmd.getColumnTypeName(i+1));
				System.out.println();
			}
		} catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
	}
}