import java.sql.*;
import java.util.Scanner;
import packages.Database;

public class main{
	public static int options(Scanner scn){
		System.out.println("[1] Search\n[2] Get All\n[3] Insert\n[4] Update\n[5] Delete\n[6] End");
		return Integer.parseInt(scn.nextLine());
	}

	public static void main(String[] args){
		Scanner scn = new Scanner(System.in);
		String database = "Inventory";
		String username = "root";
		String password = "";
		int option = 0;
		Database db = new Database(database, username, password);
		db.describeTable("Category");
	}
}